document.getElementById("inside").addEventListener("click", showPassword);

document.getElementById("password").addEventListener("onFocus", showPasswordValidation);
document.getElementById("password").addEventListener("onFocus", hidePasswordValidation);
// var letter = document.getElementById("lLetter");
// var capital = document.getElementById("uLetter");
// var number = document.getElementById("number");
// var length = document.getElementById("minChar");

document.getElementById("accountIcon").addEventListener("click", gotoAccount);

function gotoAccount(){
    location.replace("../Account.html")
}

function showPasswordValidation(){
    document.getElementById("errorMessage").style.display = "block";
}

function hidePasswordValidation(){
    document.getElementById("errorMessage").style.display = "none";
}

function showPassword(){

    let passwordText = document.getElementById("password");
    let icon = document.getElementById("inside");

    if(passwordText.type === "text"){
        passwordText.type = "password";
        icon.className = "bx bx-show";
        
    }else{
        passwordText.type = "text";
        icon.className = "bx bx-hide";
    }
}
